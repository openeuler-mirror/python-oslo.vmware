===========================
 oslo.vmware Release Notes
===========================

 .. toctree::
    :maxdepth: 1

    unreleased
    ussuri
    train
    stein
    rocky
    queens
    pike
    ocata
    newton
