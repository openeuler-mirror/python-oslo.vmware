=============================
 Newton Series Release Notes
=============================

.. release-notes::
   :branch: origin/stable/newton
