============
Installation
============

At the command line::

    $ pip install oslo.vmware

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv oslo.vmware
    $ pip install oslo.vmware
