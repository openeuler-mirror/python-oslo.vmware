===================================================
 oslo.vmware --- VMware support code for OpenStack
===================================================

The Oslo VMware library provides support for common VMware operations
and APIs.

.. toctree::
   :maxdepth: 2

   install/index
   user/index
   contributor/index
   reference/index

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
