===========================
 oslo.vmware Release Notes
===========================

 .. toctree::
    :maxdepth: 1

    unreleased
    stein
    rocky
    queens
    pike
    ocata
    newton
